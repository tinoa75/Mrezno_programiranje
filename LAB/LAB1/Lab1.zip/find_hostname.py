import socket
print socket.gethostbyaddr("8.8.8.8") 
  